#include "sort.h"

#include "map.h"
#include "queue.h"

static void swap(double *x, size_t a, size_t b)
{
	double tmp = x[a];
	x[a] = x[b];
	x[b] = tmp;
}

void insertion_sort(double *data, size_t sz)
{
	if (!data) {
		return;
	}

	for (size_t n=1; n < sz; ++n) {
		size_t idx = n;
		while (idx > 0 && data[idx] < data[idx-1]) {
			swap(data, idx, idx-1);
			--idx;
		}
	}
}

void quicksort(double *data, size_t sz)
{
	if (!data || sz < 2) {
		return;
	}

	//TODO shuffle array before picking pivot

	size_t pivot_idx = 0;
	double pivot = data[pivot_idx];

	// Partition array into (<p), (>=p)
	for (size_t n=1; n < sz; ++n) {
		if (data[n] < pivot) {
			swap(data, pivot_idx, n);
			swap(data, pivot_idx+1, n);
			++pivot_idx;
		}
	}

	// sort first chunk
	quicksort(data, pivot_idx);
	// sort second chunk
	quicksort(data + pivot_idx + 1, sz - (pivot_idx + 1));
}

static void bubble_down(double *data, size_t sz, size_t idx)
{
	while (idx < sz) {
		size_t left_idx = 2 * idx + 1;
		size_t right_idx = 2 * idx + 2;

		if (left_idx >= sz) {
			return;
		}

		size_t to_swap_idx = idx;

		if (data[left_idx] > data[to_swap_idx]) {
			to_swap_idx = left_idx;
		}
		if (right_idx < sz && data[right_idx] > data[to_swap_idx]) {
			to_swap_idx = right_idx;
		}

		if (idx == to_swap_idx) {
			// No swap necessary, can bail out
			return;
		}

		swap(data, idx, to_swap_idx);

		idx = to_swap_idx;
	}
}
static void heapify(double *data, size_t sz)
{
	for (size_t n=(sz - 1)/2; n > 0; --n) {
		bubble_down(data, sz, n);
	}

	bubble_down(data, sz, 0);
}

void heapsort(double *data, size_t sz)
{
	if (!data || sz < 2) {
		return;
	}

	heapify(data, sz);

	while (sz > 0) {
		swap(data, 0, sz-1);

		--sz;

		bubble_down(data, sz, 0);
	}
}

union indegree_count {
	size_t count;
	void *ptr;
};
static map *indegrees;
static queue *to_process;
static const graph *topo_graph;

static void insert_into_indegree_map(const void *item)
{
	union indegree_count x = {.count = graph_indegree_size(topo_graph, item)};

	map_set(indegrees, item, x.ptr);
	if (x.count == 0) {
		// The queue does not modify or alter the items in it,
		// but can if desired, so cast away the const on each item
		queue_enqueue(to_process, (void *)item);
	}

}

static void decrement_indegree_count(const void *item)
{
	union indegree_count current = {.ptr = map_get(indegrees, item)};
	--current.count;
	map_set(indegrees, item, current.ptr);
	if (current.count == 0) {
		// The queue does not modify or alter the items in it,
		// but can if desired, so cast away the const on each item
		queue_enqueue(to_process, (void *)item);
	}
}

void topo_sort(const graph *g, void ***results, size_t *sz)
{
	if (!g || !results) {
		return;
	}

	topo_graph = g;

	to_process = queue_create();
	indegrees = map_create();

	*results = calloc(graph_size(g), sizeof(**results));
	*sz = 0;

	graph_iterate_nodes(g, insert_into_indegree_map);

	while (!queue_is_empty(to_process)) {
		void *curr_item = queue_dequeue(to_process);

		graph_iterate_neighbors(g, curr_item, decrement_indegree_count);

		(*results)[*sz] = curr_item;
		++*sz;
	}

	map_destroy(indegrees);
	queue_destroy(to_process);
}
