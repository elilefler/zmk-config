#ifndef QUEUE_DOUBLE_H
#define QUEUE_DOUBLE_H

#include <stdbool.h>

typedef struct queue_ queue;

queue *queue_create(void);
void queue_destroy(queue *q);

bool queue_enqueue(queue *q, double data);
double queue_dequeue(queue *q);

bool queue_is_empty(const queue *q);

#endif
