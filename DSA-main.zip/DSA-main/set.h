#ifndef SET_H
#define SET_H

#include <stdbool.h>

typedef struct set_ set;

set *set_create(double epsilon);

bool set_add(set *s, double value);

void set_remove(set *s, double value);

bool set_is_empty(const set *s);

bool set_contains(const set *s, double value);

// Will call function() on each value stored in the set
void set_iterate(set *s, void (*function)(double));

void set_destroy(set *s);

#endif
