#ifndef SORT_H
#define SORT_H

#include <stddef.h>

#include "graph.h"

void insertion_sort(double *data, size_t sz);

void quicksort(double *data, size_t sz);

void heapsort(double *data, size_t sz);

void topo_sort(const graph *g, void ***results, size_t *sz);

#endif
