#ifndef STACK_H
#define STACK_H

#include <stdbool.h>

typedef struct stack_ stack;

stack *stack_create(void);
void stack_destroy(stack *s);

bool stack_is_empty(const stack *s);

bool stack_push(stack *s, double data);
double stack_pop(stack *s);

#endif
