#include "set.h"

#include <math.h>
#include <stdint.h>
#include <stdlib.h>

// Seems like a reasonable starting size?
// Seems like a reasonable load factor for a hashtable (out of 100)
enum { STARTING_HASHTABLE_SIZE = 15, LOAD_FACTOR = 70 };

struct node {
	double value;
	struct node *next;
};

struct set_ {
	struct node **data;
	size_t size;
	size_t capacity;
	double epsilon;
};

static size_t hash(double d, size_t capacity);

set *set_create(double epsilon)
{
	set *s = malloc(sizeof(*s));
	if (!s) {
		return NULL;
	}

	s->size = 0;
	s->capacity = STARTING_HASHTABLE_SIZE;
	s->epsilon = epsilon;
	s->data = calloc(s->capacity, sizeof(*s->data));
	if (!s->data) {
		free(s);
		return NULL;
	}

	return s;
}

bool set_add(set *s, double value)
{
	if (!s) {
		return false;
	}

	if (100 * s->size / s->capacity > LOAD_FACTOR) {
		struct node **copy = calloc(2 * s->capacity, sizeof(*copy));
		if (!copy) {
			return false;
		}

		for (size_t n=0; n < s->capacity; ++n) {
			struct node *curr = s->data[n];
			while (curr) {
				struct node *tmp = curr->next;

				// Doubled because the copy has twice as much capacity
				size_t idx = hash(curr->value, 2 * s->capacity);

				curr->next = copy[idx];
				copy[idx] = curr;
				curr = tmp;
			}

		}

		s->capacity *= 2;

		free(s->data);
		s->data = copy;
	}

	size_t idx = hash(value, s->capacity);

	struct node *curr = s->data[idx];
	while (curr) {
		if (fabs(curr->value -value) < s->epsilon) {
			return true;
		}

		curr = curr->next;
	}

	struct node *new = malloc(sizeof(*new));
	if (!new) {
		return false;
	}

	new->value = value;
	new->next = s->data[idx];

	s->data[idx] = new;
	s->size++;

	return true;
}

bool set_is_empty(const set *s)
{
	return s && s->size == 0;
}

void set_remove(set *s, double value)
{
	if (!s) {
		return;
	}

	size_t idx = hash(value, s->capacity);
	struct node **curr = &s->data[idx];
	while (*curr) {
		if (fabs((*curr)->value - value) < s->epsilon) {
			struct node *to_free = *curr;

			*curr = to_free->next;

			free(to_free);
			s->size--;
			return;
		}

		curr = &(*curr)->next;
	}
}

bool set_contains(const set *s, double value)
{
	if (!s) {
		return false;
	}

	size_t idx = hash(value, s->capacity);
	struct node *curr = s->data[idx];
	while (curr) {
		if (fabs(curr->value - value) < s->epsilon) {
			return true;
		}

		curr = curr->next;
	}

	return false;
}

void set_iterate(set *s, void (*function)(double))
{
	if (!s) {
		return;
	}

	for (size_t n=0; n < s->capacity; ++n) {
		struct node *curr = s->data[n];
		while (curr) {
			function(curr->value);

			curr = curr->next;
		}
	}
}

void set_destroy(set *s)
{
	if (!s) {
		return;
	}

	for (size_t n=0; n < s->capacity; ++n) {
		struct node *curr = s->data[n];
		while (curr) {
			struct node *tmp = curr->next;
			
			free(curr);
			curr = tmp;
		}
	}

	free(s->data);
	free(s);
}

// NB: normally will not write custom hash functions
static size_t hash(double d, size_t capacity)
{
	//TODO Remove arbitrary constant (replace with appropriate sizeof?)
	union {
		double x;
		uint8_t bytes[8];
	} as_bytes = {.x = d};

	size_t total = 0;
	for (size_t n=0; n < sizeof(as_bytes.bytes); ++n) {
		total += as_bytes.bytes[n];
	}

	return total % capacity;
}
