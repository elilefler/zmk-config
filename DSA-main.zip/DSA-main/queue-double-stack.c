#include "queue-double.h"

#include <math.h>
#include <stdlib.h>

#include "stack.h"

struct queue_ {
	stack *input;
	stack *output;
};

queue *queue_create(void)
{
	queue *q = malloc(sizeof(*q));

	if (!q) {
		return NULL;
	}

	q->input = stack_create();
	if (!q->input) {
		free(q);
		return NULL;
	}

	q->output = stack_create();
	if (!q->output) {
		free(q->input);
		free(q);
		return NULL;
	}

	return q;
}

void queue_destroy(queue *q)
{
	if (!q) {
		return;
	}

	stack_destroy(q->input);
	stack_destroy(q->output);

	free(q);
}

bool queue_enqueue(queue *q, double data)
{
	if (!q) {
		return false;
	}

	return stack_push(q->input, data);
}

double queue_dequeue(queue *q)
{
	if (!q) {
		return NAN;
	}

	if (stack_is_empty(q->output)) {
		while (!stack_is_empty(q->input)) {
			stack_push(q->output, stack_pop(q->input));
		}
	}

	return stack_pop(q->output);
}

bool queue_is_empty(const queue *q)
{
	if (!q) {
		return false;
	}

	return stack_is_empty(q->input) && stack_is_empty(q->output);
}
