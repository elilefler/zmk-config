#include "queue.h"

#include <stdlib.h>

struct node {
	void *data;
	struct node *next;
};

struct queue_ {
	struct node *head;
	struct node *tail;
};

queue *queue_create(void)
{
	queue *q = calloc(1, sizeof(*q));

	return q;
}

void queue_destroy(queue *q)
{
	if (!q) {
		return;
	}

	struct node *curr = q->head;
	while (curr) {
		struct node *to_free = curr;
		curr = curr->next;
		free(to_free);
	}

	free(q);
}

bool queue_enqueue(queue *q, void *data)
{
	if (!q || !data) {
		return false;
	}

	struct node *new = malloc(sizeof(*new));
	if (!new) {
		return false;
	}

	new->data = data;
	new->next = NULL;

	if (q->head) {
		q->tail->next = new;
	} else {
		q->head = new;
	}

	q->tail = new;

	return true;
}

void *queue_dequeue(queue *q)
{
	if (!q || queue_is_empty(q)) {
		return NULL;
	}

	void *result = q->head->data;
	struct node *to_free = q->head;
	q->head = q->head->next;

	free(to_free);
	return result;
}

bool queue_is_empty(const queue *q)
{
	return q && q->head == NULL;
}
