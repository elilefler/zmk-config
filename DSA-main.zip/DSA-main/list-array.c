#include "list.h"

#include <math.h>

struct list_ {
	double *data;
	size_t sz;
	size_t cap;
};

enum { LIST_DEFAULT_CAP=8 };

// O(1)
list *list_create(void)
{
	list *l = malloc(sizeof(*l));
	if (!l) {
		return NULL;
	}

	l->sz = 0;
	l->cap = LIST_DEFAULT_CAP;
	l->data = malloc(l->cap * sizeof(*l->data));
	if (!l->data) {
		free(l);
		return NULL;
	}

	return l;
}

// O(1)
size_t list_size(const list *l)
{
	if (!l) {
		return 0;
	}

	return l->sz;
}

// O(1)
double list_get(const list *l, size_t idx)
{
	if (!l) {
		return NAN;
	}

	if (idx >= l->sz) {
		return NAN;
	}

	return l->data[idx];
}

// O(1)
void list_set(list *l, size_t idx, double new_val)
{
	if (!l || idx >= l->sz) {
		return;
	}

	l->data[idx] = new_val;
}

// O(1), O(N) in worst case
void list_append(list *l, double new_val)
{
	if (!l) {
		return;
	}

	if (l->sz == l->cap) {
		double *tmp = realloc(l->data, 2 * l->cap * sizeof(*l->data));
		if (!tmp) {
			//TODO How to notify library user?
			return;
		}

		l->cap *= 2;
		l->data = tmp;
	}

	l->data[l->sz] = new_val;
	l->sz++;
}

// O(N)
void list_prepend(list *l, double new_val)
{
	if (!l) {
		return;
	}

	if (l->sz == l->cap) {
		double *tmp = realloc(l->data, 2 * l->cap * sizeof(*l->data));
		if (!tmp) {
			//TODO How to notify library user?
			return;
		}

		l->cap *= 2;
		l->data = tmp;
	}

	for (size_t n=l->sz; n > 0; --n) {
		l->data[n] = l->data[n-1];
	}

	l->data[0] = new_val;
	l->sz++;
}

// O(N)
// O(1) overhead per item
void list_iterate(list *l, void (*func)(double))
{
	if (!l || !func) {
		return;
	}

	for (size_t n=0; n < l->sz; ++n) {
		func(l->data[n]);
	}
}

// O(1)
void list_destroy(list *l)
{
	if (!l) {
		return;
	}

	free(l->data);
	free(l);
}
