#include <check.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

#include "../sort.h"

const double correct_data[] = {1, 1, 2, 3, 4, 5, 5, 6, 9};

const size_t data_sz = sizeof(correct_data) / sizeof(correct_data[0]);
double *data;

double *large_random_data;
size_t large_sz = 100000;

static void setup(void)
{
	data = malloc(data_sz * sizeof(*data));
	data[0] = 3;
	data[1] = 1;
	data[2] = 4;
	data[3] = 1;
	data[4] = 5;
	data[5] = 9;
	data[6] = 2;
	data[7] = 6;
	data[8] = 5;

	large_random_data = malloc(large_sz * sizeof(*data));
	for (size_t n=0; n < large_sz; ++n) {
		large_random_data[n] = drand48();
	}

}

static void teardown(void)
{
	free(data);
	free(large_random_data);
}

START_TEST(test_toposort_empty)
{
	// This is intentionally empty to sort nothing
	graph *g = graph_create(GRAPH_STRCMP, NULL);

	void **sorted = NULL;
	size_t sorted_sz = 0;
	topo_sort(g, &sorted, &sorted_sz);

	ck_assert_uint_eq(sorted_sz, 0);

	graph_destroy(g);
}
END_TEST

START_TEST(test_toposort_standard)
{
	FILE *input = fopen("test/graph02.txt", "r");
	ck_assert_ptr_nonnull(input);
	graph *g = graph_deserialize(input);
	ck_assert_ptr_nonnull(g);
	fclose(input);

	void **sorted = NULL;
	size_t sorted_sz = 0;
	topo_sort(g, &sorted, &sorted_sz);

	ck_assert_uint_eq(sorted_sz, 13);
	ck_assert_str_eq(sorted[0], "DVCS");
	ck_assert_str_eq(sorted[12], "Graduation");

	graph_destroy(g);
}
END_TEST

START_TEST(test_quicksort_empty)
{
	double data[] = {0};
	// TODO This is intentionally 0 to sort nothing
	quicksort(data, 0);

	ck_assert(true);
}
END_TEST

START_TEST(test_quicksort_standard)
{
	quicksort(data, data_sz);

	for (size_t n=0; n < data_sz; ++n) {
		ck_assert_double_eq_tol(data[n], correct_data[n], 0.001);
	}
}
END_TEST

START_TEST(test_quicksort_large)
{
	quicksort(large_random_data, large_sz);

	for (size_t n=1; n < large_sz; ++n) {
		ck_assert_double_le(large_random_data[n-1], large_random_data[n]);
	}
}
END_TEST

START_TEST(test_heapsort_empty)
{
	double data[] = {0};
	// TODO This is intentionally 0 to sort nothing
	heapsort(data, 0);

	ck_assert(true);
}
END_TEST

START_TEST(test_heapsort_standard)
{
	heapsort(data, data_sz);

	for (size_t n=0; n < data_sz; ++n) {
		ck_assert_double_eq_tol(data[n], correct_data[n], 0.001);
	}
}
END_TEST

START_TEST(test_heapsort_large)
{
	heapsort(large_random_data, large_sz);

	for (size_t n=1; n < large_sz; ++n) {
		ck_assert_double_le(large_random_data[n-1], large_random_data[n]);
	}
}
END_TEST

START_TEST(test_insertion_sort_empty)
{
	double data[] = {0};
	// TODO This is intentionally 0 to sort nothing
	insertion_sort(data, 0);

	ck_assert(true);
}
END_TEST

START_TEST(test_insertion_sort_standard)
{
	insertion_sort(data, data_sz);

	for (size_t n=0; n < data_sz; ++n) {
		ck_assert_double_eq_tol(data[n], correct_data[n], 0.001);
	}
}
END_TEST

START_TEST(test_insertion_sort_large)
{
	insertion_sort(large_random_data, large_sz);

	for (size_t n=1; n < large_sz; ++n) {
		ck_assert_double_le(large_random_data[n-1], large_random_data[n]);
	}
}
END_TEST

Suite *sort_test_suite(void)
{
	Suite *s1 = suite_create("Sort");
	srand48(time(NULL));

	TCase *tc1 = tcase_create("TC 1");
	tcase_add_checked_fixture(tc1, setup, teardown);

	tcase_add_test(tc1, test_insertion_sort_empty);
	tcase_add_test(tc1, test_insertion_sort_standard);

	tcase_add_test(tc1, test_quicksort_empty);
	tcase_add_test(tc1, test_quicksort_standard);

	tcase_add_test(tc1, test_heapsort_empty);
	tcase_add_test(tc1, test_heapsort_standard);

	tcase_add_test(tc1, test_toposort_empty);
	tcase_add_test(tc1, test_toposort_standard);

	suite_add_tcase(s1, tc1);

	TCase *profile = tcase_create("TC Profile");
	tcase_set_tags(profile, "profile");
	tcase_add_checked_fixture(profile, setup, teardown);
	tcase_add_test(profile, test_insertion_sort_large);
	tcase_add_test(profile, test_quicksort_large);
	tcase_add_test(profile, test_heapsort_large);

	suite_add_tcase(s1, profile);


	return s1;
}
