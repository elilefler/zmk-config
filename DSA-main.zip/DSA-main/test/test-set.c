#include <check.h>
#include <stdlib.h>
#include <time.h>

#include "../set.h"

START_TEST(test_set_empty)
{
	set *s = set_create(0.001);

	ck_assert(set_is_empty(s));

	ck_assert(set_add(s, 3.14));

	ck_assert(!set_is_empty(s));

	ck_assert(set_add(s, 2.71));

	set_destroy(s);
}
END_TEST

START_TEST(test_set_contains)
{
	set *s = set_create(0.001);

	ck_assert(set_add(s, 3.14));
	ck_assert(set_add(s, 2.71));
	ck_assert(set_add(s, 6.02));
	ck_assert(set_add(s, 8.67));

	ck_assert(set_contains(s, 8.67));
	ck_assert(set_contains(s, 2.71));
	ck_assert(set_contains(s, 6.02));
	ck_assert(set_contains(s, 3.14));

	set_destroy(s);
}
END_TEST

static double total = 0;
void sum_values(double x)
{
	total += x;
}

START_TEST(test_set_iterate)
{
	set *s = set_create(0.001);

	total = 0.0;
	ck_assert(set_add(s, 3.14));
	ck_assert(set_add(s, 2.71));
	ck_assert(set_add(s, 6.02));
	ck_assert(set_add(s, 6.02));
	ck_assert(set_add(s, 6.02));
	ck_assert(set_add(s, 8.67));

	set_iterate(s, sum_values);

	ck_assert_double_eq_tol(total, 20.54, 0.0001);

	set_destroy(s);
}
END_TEST

START_TEST(test_set_removal)
{
	set *s = set_create(0.001);

	ck_assert(set_add(s, 3.14));
	ck_assert(set_add(s, 2.71));
	ck_assert(set_add(s, 6.02));
	ck_assert(set_add(s, 8.67));
	ck_assert(set_add(s, 1.00));
	ck_assert(set_add(s, 3.00));

	ck_assert(set_contains(s, 2.71));

	set_remove(s, 2.71);

	ck_assert(!set_contains(s, 2.71));
	ck_assert(set_contains(s, 3.14));
	ck_assert(set_contains(s, 6.02));
	ck_assert(set_contains(s, 8.67));
	ck_assert(set_contains(s, 1.00));
	ck_assert(set_contains(s, 3.00));

	set_remove(s, 3.14);

	ck_assert(!set_contains(s, 2.71));
	ck_assert(!set_contains(s, 3.14));
	ck_assert(set_contains(s, 6.02));
	ck_assert(set_contains(s, 8.67));
	ck_assert(set_contains(s, 1.00));
	ck_assert(set_contains(s, 3.00));

	// Confirm that removing nonexistent values doesn't crash
	set_remove(s, 500);

	ck_assert(set_contains(s, 6.02));
	ck_assert(set_contains(s, 8.67));
	ck_assert(set_contains(s, 1.00));
	ck_assert(set_contains(s, 3.00));

	set_destroy(s);
}
END_TEST

START_TEST(test_set_profile)
{
	set *s = set_create(0.001);
	for (size_t n=0; n < 5000; ++n) {
		ck_assert(set_add(s, n));
	}

	ck_assert(!set_contains(s, 5000));
	ck_assert(set_contains(s, 4999));
	ck_assert(set_contains(s, 4998));
	ck_assert(set_contains(s, 0));

	set_destroy(s);
}
END_TEST

Suite *set_test_suite(void)
{
	Suite *s1 = suite_create("Set");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_set_empty);
	tcase_add_test(tc1, test_set_contains);
	tcase_add_test(tc1, test_set_iterate);
	tcase_add_test(tc1, test_set_removal);

	TCase *profile = tcase_create("TC Profile");
	tcase_set_tags(profile, "profile");
	tcase_set_timeout(profile, 10);
	tcase_add_test(profile, test_set_profile);

	suite_add_tcase(s1, tc1);
	suite_add_tcase(s1, profile);

	return s1;
}
