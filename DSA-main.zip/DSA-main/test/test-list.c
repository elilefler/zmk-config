#include <check.h>

#include "../list.h"

union blob {
	double d;
	void *ptr;
};

START_TEST(test_list_size)
{
	list *x = list_create(NULL);
	ck_assert_int_eq(list_size(x), 0);

	union blob tmp = {.d = 3.14};
	list_append(x, tmp.ptr);
	ck_assert_int_eq(list_size(x), 1);
	list_prepend(x, tmp.ptr);
	ck_assert_int_eq(list_size(x), 2);
	list_destroy(x);
} END_TEST

static double total = 0;
static void add_up(void *item)
{
	union blob x = {.ptr = item};
	total += x.d;
}

START_TEST(test_list_iterate)
{
	list *x = list_create(NULL);

	for (size_t n=0; n < 11; ++n) {
		union blob tmp = {.d = n};
		list_append(x, tmp.ptr);
	}

	list_iterate(x, add_up);

	ck_assert_double_eq_tol(total, 55, 0.0001);

	list_destroy(x);
} END_TEST

START_TEST(test_list_append)
{
	list *x = list_create(NULL);

	for (size_t n=0; n < 17; ++n) {
		union blob tmp = {.d = n + 0.34};
		list_append(x, tmp.ptr);
	}

	union blob result = {.ptr = list_get(x, 0)};
	ck_assert_double_eq_tol(result.d, 0.34, 0.001);
	result.ptr = list_get(x, 15);
	ck_assert_double_eq_tol(result.d, 15.34, 0.001);
	result.ptr = list_get(x, 16);
	ck_assert_double_eq_tol(result.d, 16.34, 0.001);

	list_destroy(x);
}
END_TEST

START_TEST(test_list_append_prepend_mix)
{
	list *x = list_create(NULL);
	union blob tmp = {.d = 16.34};
	list_prepend(x, tmp.ptr);
	tmp.d = 15.34;
	list_append(x, tmp.ptr);

	union blob result = {.ptr = list_get(x, 0)};
	ck_assert_double_eq_tol(result.d, 16.34, 0.001);
	result.ptr = list_get(x, 1);
	ck_assert_double_eq_tol(result.d, 15.34, 0.001);

	list_destroy(x);
}
END_TEST

START_TEST(test_list_prepend)
{
	list *x = list_create(NULL);

	for (size_t n=0; n < 17; ++n) {
		union blob tmp = {.d = n + 0.34};
		list_prepend(x, tmp.ptr);
	}

	union blob result = {.ptr = list_get(x, 0)};
	ck_assert_double_eq_tol(result.d, 16.34, 0.001);
	result.ptr = list_get(x, 1);
	ck_assert_double_eq_tol(result.d, 15.34, 0.001);
	result.ptr = list_get(x, 16);
	ck_assert_double_eq_tol(result.d, 0.34, 0.001);

	list_destroy(x);
}
END_TEST

START_TEST(test_list_set_get)
{
	list *x = list_create(NULL);
	union blob tmp = {.d = 2.71};
	list_append(x, tmp.ptr);
	tmp.d = 3.14;
	list_append(x, tmp.ptr);

	union blob result = {.ptr = list_get(x, 0)};
	ck_assert_double_eq_tol(result.d, 2.71, 0.001);
	result.ptr = list_get(x, 1);
	ck_assert_double_eq_tol(result.d, 3.14, 0.001);

	tmp.d = 5.42;
	list_set(x, 0, tmp.ptr);
	tmp.d = 6.28;
	list_set(x, 1, tmp.ptr);

	result.ptr = list_get(x, 0);
	ck_assert_double_eq_tol(result.d, 5.42, 0.001);
	result.ptr = list_get(x, 1);
	ck_assert_double_eq_tol(result.d, 6.28, 0.001);

	list_destroy(x);
} END_TEST

START_TEST(test_list_get_fails_null)
{
	list *x = list_create(NULL);

	ck_assert_ptr_null(list_get(x, 1));

	list_destroy(x);
}
END_TEST

Suite *list_test_suite(void)
{
	Suite *s1 = suite_create("List");

	TCase *tc1 = tcase_create("TC 1");

	suite_add_tcase(s1, tc1);

	tcase_add_test(tc1, test_list_size);
	tcase_add_test(tc1, test_list_iterate);
	tcase_add_test(tc1, test_list_append);
	tcase_add_test(tc1, test_list_append_prepend_mix);
	tcase_add_test(tc1, test_list_prepend);
	tcase_add_test(tc1, test_list_set_get);
	tcase_add_test(tc1, test_list_get_fails_null);

	return s1;
}
