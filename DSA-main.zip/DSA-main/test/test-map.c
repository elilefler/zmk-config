#include <check.h>
#include <stdlib.h>
#include <time.h>

#include "../map.h"

union blob {
	double d;
	void *ptr;
};

START_TEST(test_map_empty)
{
	map *m = map_create();

	ck_assert_uint_eq(map_size(m), 0);

	union blob x = {.d = 3.14};

	ck_assert(map_set(m, "First", x.ptr));

	ck_assert_uint_eq(map_size(m), 1);

	map_destroy(m);
}
END_TEST

static double sum = 0;
static void value_sum(const char *key, void *value)
{
	(void)key;
	union blob x = {.ptr = value};
	sum += x.d;
}

START_TEST(test_map_iterate_values)
{
	map *m = map_create();

	union blob x = {.d = 3.14};

	ck_assert(map_set(m, "First", x.ptr));
	x.d = 2.71;
	ck_assert(map_set(m, "Second", x.ptr));
	x.d = 6.02;
	ck_assert(map_set(m, "Third", x.ptr));

	map_iterate(m, value_sum);

	ck_assert_double_eq_tol(sum, 11.87, 0.001);

	map_destroy(m);
}
END_TEST

START_TEST(test_map_expansion)
{
	map *m = map_create();

	union blob x = {.d = 3.14};

	ck_assert(map_set(m, "alfa", x.ptr));
	x.d = 2.14;
	ck_assert(map_set(m, "alfa", x.ptr));
	x.d = 1.14;
	ck_assert(map_set(m, "alfa", x.ptr));

	x.d = 2.71;
	ck_assert(map_set(m, "bravo", x.ptr));
	x.d = 3.71;
	ck_assert(map_set(m, "charlie", x.ptr));
	x.d = 4.71;
	ck_assert(map_set(m, "delta", x.ptr));
	x.d = 5.71;
	ck_assert(map_set(m, "ecco", x.ptr));
	x.d = 6.71;
	ck_assert(map_set(m, "foxtrot", x.ptr));
	x.d = 7.71;
	ck_assert(map_set(m, "golf", x.ptr));
	x.d = 8.71;
	ck_assert(map_set(m, "india", x.ptr));
	x.d = 9.71;
	ck_assert(map_set(m, "hotel", x.ptr));
	x.d = 10.71;
	ck_assert(map_set(m, "juliet", x.ptr));
	x.d = 11.71;
	ck_assert(map_set(m, "zulu", x.ptr));
	x.d = 12.71;
	ck_assert(map_set(m, "xebra", x.ptr));

	union blob result;
	result.ptr = map_get(m, "bravo");
	ck_assert_double_eq_tol(result.d, 2.71, 0.001);
	result.ptr = map_get(m, "charlie");
	ck_assert_double_eq_tol(result.d, 3.71, 0.001);
	result.ptr = map_get(m, "delta");
	ck_assert_double_eq_tol(result.d, 4.71, 0.001);
	result.ptr = map_get(m, "ecco");
	ck_assert_double_eq_tol(result.d, 5.71, 0.001);
	result.ptr = map_get(m, "foxtrot");
	ck_assert_double_eq_tol(result.d, 6.71, 0.001);
	result.ptr = map_get(m, "golf");
	ck_assert_double_eq_tol(result.d, 7.71, 0.001);
	result.ptr = map_get(m, "india");
	ck_assert_double_eq_tol(result.d, 8.71, 0.001);
	result.ptr = map_get(m, "hotel");
	ck_assert_double_eq_tol(result.d, 9.71, 0.001);
	result.ptr = map_get(m, "juliet");
	ck_assert_double_eq_tol(result.d, 10.71, 0.001);
	result.ptr = map_get(m, "zulu");
	ck_assert_double_eq_tol(result.d, 11.71, 0.001);
	result.ptr = map_get(m, "xebra");
	ck_assert_double_eq_tol(result.d, 12.71, 0.001);

	// This portion tests for duplicate pairs inserted for a given key
	// Should only store the last value set
	result.ptr = map_get(m, "alfa");
	ck_assert_double_eq_tol(result.d, 1.14, 0.001);

	map_destroy(m);
}
END_TEST

START_TEST(test_map_cache)
{
	map *m = map_create();

	char to_change[] = "First";

	union blob x = {.d = 3.14};
	ck_assert(map_set(m, to_change, x.ptr));
	union blob result = {.ptr = map_get(m, to_change)};
	ck_assert_double_eq_tol(result.d, 3.14, 0.001);

	to_change[0] = 'B';
	to_change[1] = 'u';

	ck_assert_ptr_null(map_get(m, to_change));
	result.ptr = map_get(m, "First");
	ck_assert_double_eq_tol(result.d, 3.14, 0.001);

	map_destroy(m);
}

static double total = 0;
static void value_total_if_key_contains_i(const char *key, void *value)
{
	union blob x = {.ptr = value};
	if (strchr(key, 'i')) {
		total += x.d;
	}
}

START_TEST(test_map_iterate_filter)
{
	map *m = map_create();

	union blob x = {.d = 3.14};

	ck_assert(map_set(m, "First", x.ptr));
	x.d = 2.71;
	ck_assert(map_set(m, "Second", x.ptr));
	x.d = 6.02;
	ck_assert(map_set(m, "Third", x.ptr));

	map_iterate(m, value_total_if_key_contains_i);

	ck_assert_double_eq_tol(total, 9.16, 0.001);

	map_destroy(m);
}
END_TEST


Suite *map_test_suite(void)
{
	Suite *s1 = suite_create("Map");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_map_empty);
	tcase_add_test(tc1, test_map_cache);
	tcase_add_test(tc1, test_map_expansion);
	tcase_add_test(tc1, test_map_iterate_values);
	tcase_add_test(tc1, test_map_iterate_filter);

	suite_add_tcase(s1, tc1);

	return s1;
}
