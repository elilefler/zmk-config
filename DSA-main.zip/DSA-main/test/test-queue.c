#include <check.h>

#include "../queue.h"

START_TEST(test_queue_empty)
{
	queue *s = queue_create();

	ck_assert(queue_is_empty(s));

	char able[] = "able";
	queue_enqueue(s, able);
	ck_assert(!queue_is_empty(s));

	queue_destroy(s);
}
END_TEST

START_TEST(test_queue_fifo)
{
	queue *s = queue_create();

	char able[] = "able";
	char baker[] = "baker";
	char charlie[] = "charlie";
	queue_enqueue(s, able);
	queue_enqueue(s, baker);
	queue_enqueue(s, charlie);

	ck_assert_str_eq(queue_dequeue(s), "able");
	ck_assert_str_eq(queue_dequeue(s), "baker");
	ck_assert_str_eq(queue_dequeue(s), "charlie");

	queue_destroy(s);
}
END_TEST

Suite *queue_test_suite(void)
{
	Suite *s1 = suite_create("Queue");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_queue_empty);
	tcase_add_test(tc1, test_queue_fifo);

	suite_add_tcase(s1, tc1);

	return s1;
}
