#include <check.h>
#include <stdlib.h>

#include "../pqueue.h"

START_TEST(test_pqueue_empty)
{
	pqueue *pq = pqueue_create(MIN_PQUEUE);

	ck_assert(pqueue_is_empty(pq));

	char alfa[] = "Alfa";

	pqueue_enqueue(pq, 1, alfa);

	ck_assert(!pqueue_is_empty(pq));

	pqueue_destroy(pq);
}
END_TEST

START_TEST(test_pqueue_order_max)
{
	pqueue *pq = pqueue_create(MAX_PQUEUE);

	char alfa[] = "Alfa";
	char bravo[] = "Bravo";
	char charlie[] = "Charlie";

	ck_assert(pqueue_enqueue(pq, 1, alfa));
	ck_assert(pqueue_enqueue(pq, 5, bravo));
	ck_assert(pqueue_enqueue(pq, 10, charlie));

	char *result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Charlie");

	result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Bravo");

	result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Alfa");

	ck_assert(pqueue_is_empty(pq));

	pqueue_destroy(pq);
}
END_TEST


START_TEST(test_pqueue_ordered)
{
	pqueue *pq = pqueue_create(MIN_PQUEUE);

	char alfa[] = "Alfa";
	char bravo[] = "Bravo";
	char charlie[] = "Charlie";
	char delta[] = "Delta";
	char echo[] = "Echo";

	ck_assert(pqueue_enqueue(pq, 1, alfa));
	ck_assert(pqueue_enqueue(pq, 5, bravo));
	ck_assert(pqueue_enqueue(pq, 10, charlie));
	ck_assert(pqueue_enqueue(pq, 2, delta));
	ck_assert(pqueue_enqueue(pq, 7, echo));

	char *result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Alfa");

	result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Delta");

	result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Bravo");

	double priority;
	result = pqueue_dequeue(pq, &priority);
	ck_assert_str_eq(result, "Echo");
	ck_assert_float_eq_tol(priority, 7, 0.001);

	result = pqueue_dequeue(pq, NULL);
	ck_assert_str_eq(result, "Charlie");

	ck_assert(pqueue_is_empty(pq));

	pqueue_destroy(pq);
}
END_TEST


Suite *pqueue_test_suite(void)
{
	Suite *s1 = suite_create("Priority Queue");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_pqueue_empty);
	tcase_add_test(tc1, test_pqueue_order_max);
	tcase_add_test(tc1, test_pqueue_ordered);

	suite_add_tcase(s1, tc1);

	return s1;
}
