#include <check.h>
#include <stdlib.h>

#include "../graph.h"

// Read from graph01.txt
static graph *g;

static void setup(void)
{
	FILE *fp = fopen("test/graph01.txt", "r");
	g = graph_deserialize(fp);

	fclose(fp);
}

static void teardown(void)
{
	graph_destroy(g);
}


START_TEST(test_graph_empty)
{
	ck_assert_ptr_nonnull(g);

	ck_assert(graph_contains(g, "Alfa"));
}
END_TEST

struct date_test {
	int day;
	int month;
	int year;
};

static int date_cmp(const void *a, const void *b)
{
	const struct date_test *one = a;
	const struct date_test *two = b;

	return one->year - two->year || one->month - two->month || one->day - two->day;
}

START_TEST(test_graph_nonstring)
{
	graph *g = graph_create(date_cmp, NULL);

	ck_assert_ptr_nonnull(g);

	struct date_test alfa = {23, 1, 2023};
	struct date_test bravo = {30, 11, 1999};

	ck_assert(graph_add_node(g, &alfa));
	ck_assert(graph_add_node(g, &bravo));

	ck_assert(graph_contains(g, &alfa));

	struct date_test charlie = {30, 11, 1999};

	// Should be there since compares the same as bravo
	ck_assert_int_eq(date_cmp(&charlie, &bravo), 0);
	ck_assert(graph_contains(g, &charlie));

	graph_destroy(g);
}
END_TEST


START_TEST(test_graph_no_duplicates)
{
	char alfa[] = "Alfa";
	ck_assert(graph_add_node(g, alfa));

	ck_assert(graph_contains(g, "Alfa"));
	ck_assert(graph_contains(g, "Bravo"));

	graph_remove_node(g, alfa);

	ck_assert(!graph_contains(g, "Alfa"));
	ck_assert(graph_contains(g, "Bravo"));
}
END_TEST

START_TEST(test_graph_size)
{
	ck_assert_uint_eq(graph_size(g), 4);

	char *echo = strdup("Echo");

	ck_assert(graph_add_node(g, echo));
	ck_assert_uint_eq(graph_size(g), 5);
}
END_TEST

START_TEST(test_graph_add_edges)
{
	ck_assert_double_eq_tol(graph_get_edge_weight(g, "Alfa", "Bravo"), 3.7, 0.001);
	ck_assert_double_nan(graph_get_edge_weight(g, "Bravo", "Alfa"));

	graph_remove_edge(g, "Alfa", "Bravo");
	ck_assert_double_nan(graph_get_edge_weight(g, "Alfa", "Bravo"));
}
END_TEST

START_TEST(test_graph_degree_counts)
{
	ck_assert_uint_eq(graph_outdegree_size(g, "Doesn't Exist"), 0);
	ck_assert_uint_eq(graph_outdegree_size(g, "Alfa"), 1);
	ck_assert_uint_eq(graph_outdegree_size(g, "Bravo"), 0);
	ck_assert_uint_eq(graph_outdegree_size(g, "Charlie"), 2);
	ck_assert_uint_eq(graph_outdegree_size(g, "Delta"), 2);

	ck_assert_uint_eq(graph_indegree_size(g, "Doesn't Exist"), 0);
	ck_assert_uint_eq(graph_indegree_size(g, "Alfa"), 2);
	ck_assert_uint_eq(graph_indegree_size(g, "Bravo"), 2);
	ck_assert_uint_eq(graph_indegree_size(g, "Delta"), 0);
}
END_TEST

static size_t sum = 0;
static void sum_str_length(const void *item)
{
	sum += strlen(item);
}

START_TEST(test_graph_iterate_nodes)
{
	sum = 0;
	graph_iterate_nodes(g, sum_str_length);
	ck_assert_uint_eq(sum, 21);
}
END_TEST

START_TEST(test_graph_iterate_neighbors)
{
	sum = 0;
	graph_iterate_neighbors(g, "Doesn't Exist", sum_str_length);
	ck_assert_uint_eq(sum, 0);

	sum = 0;
	graph_iterate_neighbors(g, "Alfa", sum_str_length);
	ck_assert_uint_eq(sum, 5);

	sum = 0;
	graph_iterate_neighbors(g, "Bravo", sum_str_length);
	ck_assert_uint_eq(sum, 0);

	sum = 0;
	graph_iterate_neighbors(g, "Charlie", sum_str_length);
	ck_assert_uint_eq(sum, 9);
}
END_TEST


Suite *graph_test_suite(void)
{
	Suite *s1 = suite_create("Graph");

	TCase *tc1 = tcase_create("TC 1");
	tcase_add_checked_fixture(tc1, setup, teardown);

	tcase_add_test(tc1, test_graph_empty);
	tcase_add_test(tc1, test_graph_size);
	tcase_add_test(tc1, test_graph_nonstring);
	tcase_add_test(tc1, test_graph_no_duplicates);
	tcase_add_test(tc1, test_graph_add_edges);
	tcase_add_test(tc1, test_graph_degree_counts);
	tcase_add_test(tc1, test_graph_iterate_nodes);
	tcase_add_test(tc1, test_graph_iterate_neighbors);

	suite_add_tcase(s1, tc1);

	return s1;
}
