#include <check.h>

#include "../stack.h"

START_TEST(test_stack_empty)
{
	stack *s = stack_create();

	ck_assert(stack_is_empty(s));

	stack_push(s, 9);
	ck_assert(!stack_is_empty(s));

	stack_destroy(s);
}
END_TEST

START_TEST(test_stack_reverses)
{
	stack *s = stack_create();

	stack_push(s, 9);
	stack_push(s, 8);
	stack_push(s, 7);
	stack_push(s, 6);

	ck_assert_double_eq_tol(stack_pop(s), 6, 0.001);
	ck_assert_double_eq_tol(stack_pop(s), 7, 0.001);
	ck_assert_double_eq_tol(stack_pop(s), 8, 0.001);
	ck_assert_double_eq_tol(stack_pop(s), 9, 0.001);

	stack_destroy(s);
}
END_TEST

Suite *stack_test_suite(void)
{
	Suite *s1 = suite_create("Stack");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_stack_empty);
	tcase_add_test(tc1, test_stack_reverses);

	suite_add_tcase(s1, tc1);

	return s1;
}
