#include <check.h>
#include <stdlib.h>

#include "../path.h"

const char *src;
const char *dst;

void find_src_and_dst(const void *data)
{
	if (strcmp(data, "Zero") == 0) {
		src = data;
	}
	if (strcmp(data, "Two") == 0) {
		dst = data;
	}
}

START_TEST(test_path_dijkstra)
{
	FILE *fp = fopen("test/graph03.txt", "r");
	graph *g = graph_deserialize(fp);
	fclose(fp);

	graph_iterate_nodes(g, find_src_and_dst);

	list *route = dijkstra_path(g, src, dst);

	ck_assert_ptr_nonnull(route);

	/*
	for (size_t n=0; n < list_size(route); ++n) {
		printf("%s →\n", list_get(route, n));
	}
	*/
	ck_assert_uint_eq(list_size(route), 4);
	ck_assert_str_eq(list_get(route, 0), "Zero");
	ck_assert_str_eq(list_get(route, 1), "One");
	ck_assert_str_eq(list_get(route, 2), "Three");
	ck_assert_str_eq(list_get(route, 3), "Two");

	list_destroy(route);

	graph_destroy(g);
}
END_TEST

Suite *path_test_suite(void)
{
	Suite *s1 = suite_create("Path");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_path_dijkstra);

	suite_add_tcase(s1, tc1);

	return s1;
}
