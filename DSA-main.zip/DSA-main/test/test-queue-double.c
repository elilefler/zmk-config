#include <check.h>

#include "../queue-double.h"

START_TEST(test_queue_empty)
{
	queue *s = queue_create();

	ck_assert(queue_is_empty(s));

	queue_enqueue(s, 9);
	ck_assert(!queue_is_empty(s));

	queue_destroy(s);
}
END_TEST

START_TEST(test_queue_fifo)
{
	queue *s = queue_create();

	queue_enqueue(s, 9);
	queue_enqueue(s, 8);
	queue_enqueue(s, 7);
	queue_enqueue(s, 6);

	ck_assert_double_eq_tol(queue_dequeue(s), 9, 0.001);
	ck_assert_double_eq_tol(queue_dequeue(s), 8, 0.001);
	ck_assert_double_eq_tol(queue_dequeue(s), 7, 0.001);
	ck_assert_double_eq_tol(queue_dequeue(s), 6, 0.001);

	queue_destroy(s);
}
END_TEST

Suite *queue_double_test_suite(void)
{
	Suite *s1 = suite_create("Queue");

	TCase *tc1 = tcase_create("TC 1");

	tcase_add_test(tc1, test_queue_empty);
	tcase_add_test(tc1, test_queue_fifo);

	suite_add_tcase(s1, tc1);

	return s1;
}
