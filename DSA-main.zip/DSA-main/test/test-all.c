#include <check.h>

Suite *list_test_suite(void);
Suite *stack_test_suite(void);
Suite *queue_test_suite(void);
Suite *queue_test_suite(void);
Suite *set_test_suite(void);
Suite *map_test_suite(void);
Suite *pqueue_test_suite(void);
Suite *graph_test_suite(void);
Suite *sort_test_suite(void);
Suite *path_test_suite(void);

int main(void)
{
	SRunner *sr = srunner_create(NULL);

	srunner_add_suite(sr, list_test_suite());
	srunner_add_suite(sr, stack_test_suite());
	srunner_add_suite(sr, queue_test_suite());
	srunner_add_suite(sr, set_test_suite());
	srunner_add_suite(sr, map_test_suite());
	srunner_add_suite(sr, pqueue_test_suite());
	srunner_add_suite(sr, graph_test_suite());
	srunner_add_suite(sr, sort_test_suite());
	srunner_add_suite(sr, path_test_suite());

	srunner_run_all(sr, CK_NORMAL);

	srunner_free(sr);
}
