#include "stack.h"

#include <math.h>
#include <stdlib.h>

struct node {
	double data;
	struct node *next;
};

struct stack_ {
	struct node *top;
};

stack *stack_create(void)
{
	stack *s = malloc(sizeof(*s));
	if (!s) {
		return NULL;
	}

	s->top = NULL;
	return s;
}

void stack_destroy(stack *s)
{
	if (!s) {
		return;
	}

	struct node *curr = s->top;

	while (curr) {
		struct node *tmp = curr->next;
		free(curr);
		curr = tmp;
	}

	free(s);
}

bool stack_is_empty(const stack *s)
{
	if (!s) {
		//TODO Should we return something else?
		return false;
	}

	return s->top == NULL;
}

bool stack_push(stack *s, double data)
{
	if (!s) {
		return false;
	}

	struct node *new = malloc(sizeof(*new));
	new->data = data;
	new->next = s->top;

	s->top = new;

	return true;
}

double stack_pop(stack *s)
{
	if (!s || stack_is_empty(s)) {
		return NAN;
	}

	double value = s->top->data;
	struct node *tmp = s->top->next;

	free(s->top);
	s->top = tmp;

	return value;
}
