#include "set.h"

#include <math.h>
#include <stdlib.h>

struct node {
	double data;
	struct node *left;
	struct node *right;
};

struct set_ {
	struct node *root;
	double epsilon;
};

static struct node **tree_search(struct node **t, double needle, double epsilon)
{
	if (!*t) {
		return t;
	}

	if (fabs((*t)->data - needle) < epsilon) {
		return t;
	}

	if (needle < (*t)->data) {
		return tree_search(&(*t)->left, needle, epsilon);
	}
	else {
		return tree_search(&(*t)->right, needle, epsilon);
	}
}

static struct node **tree_max(struct node **t)
{
	if ((*t)->right) {
		return tree_max(&(*t)->right);
	} else {
		return t;
	}
}

static size_t tree_height(const struct node *t)
{
	if (!t) {
		return 0;
	}

	size_t left = t->left ? tree_height(t->left) : 0;
	size_t right = t->right ? tree_height(t->right) : 0;

	return 1 + (left > right ? left : right);
}

static void tree_inorder(struct node *t, void (*func)(void *))
{
	if (!t) {
		return;
	}

	tree_inorder(t->left, func);
	func(t);
	tree_inorder(t->right, func);
}

static void tree_postorder(struct node *t, void (*func)(void *))
{
	if (!t) {
		return;
	}

	tree_postorder(t->left, func);
	tree_postorder(t->right, func);
	func(t);
}

set *set_create(double epsilon)
{
	set *s = malloc(sizeof(*s));
	if (!s) {
		return NULL;
	}

	s->root = NULL;
	s->epsilon = epsilon;

	return s;
}

static void rotate_LL(struct node **t)
{
	struct node *new_root = (*t)->right;

	(*t)->right = new_root->left;
	new_root->left = *t;
	*t = new_root;
}

static void rotate_RR(struct node **t)
{
	struct node *new_root = (*t)->left;

	(*t)->left = new_root->right;
	new_root->right = *t;
	*t = new_root;
}

static void rotate_LR(struct node **t)
{
	struct node *new_root = (*t)->right->left;

	(*t)->right->left = new_root->right;
	struct node *tmp = (*t)->right;
	(*t)->right = new_root->left;
	new_root->right = tmp;
	new_root->left = *t;

	*t = new_root;
}

static void rotate_RL(struct node **t)
{
	struct node *new_root = (*t)->left->right;

	(*t)->left->right = new_root->left;
	struct node *tmp = (*t)->left;
	(*t)->left = new_root->right;
	new_root->left = tmp;
	new_root->right = *t;

	*t = new_root;
}

static void tree_insert(struct node **t, struct node *new, double epsilon)
{
	if (!*t) {
		*t = new;
		return;
	}

	if (fabs((*t)->data - new->data) < epsilon) {
		// Duplicate found! (or close enough)
		free(new);
	} else if (new->data < (*t)->data) {
		tree_insert(&(*t)->left, new, epsilon);

		size_t r_height = tree_height((*t)->right);
		size_t l_height = tree_height((*t)->left);

		if (l_height > r_height + 1) {
			// Need to rebalance with a rotation to the right
			if (new->data < (*t)->left->data) {
				rotate_RR(t);
			} else if (new->data > (*t)->left->data) {
				rotate_RL(t);
			}
		}

	} else {
		tree_insert(&(*t)->right, new, epsilon);

		size_t r_height = tree_height((*t)->right);
		size_t l_height = tree_height((*t)->left);

		if (r_height > l_height + 1) {
			// Need to rebalance with a rotation to the left
			if (new->data < (*t)->right->data) {
				rotate_LR(t);
			} else if (new->data > (*t)->right->data) {
				rotate_LL(t);
			}
		}

	}
}

bool set_add(set *s, double value)
{
	if (!s) {
		return false;
	}

	struct node *new = malloc(sizeof(*new));
	if (!new) {
		return false;
	}
	new->data = value;
	new->left = NULL;
	new->right = NULL;

	tree_insert(&s->root, new, s->epsilon);

	return true;
}

void set_remove(set *s, double value)
{
	if (!s) {
		return;
	}

	struct node **found = tree_search(&s->root, value, s->epsilon);

	if (!*found) {
		return;
	}

	struct node *to_promote = NULL;

	if (!((*found)->left && (*found)->right)) {
		if ((*found)->left) {
			to_promote = (*found)->left;
		} else {
			to_promote = (*found)->right;
		}
	} else {
		struct node **max_left = tree_max(&(*found)->left);
		to_promote = *max_left;
		*max_left = (*max_left)->left;
		to_promote->left = (*found)->left;
		to_promote->right = (*found)->right;
	}

	//TODO How to rebalance the tree?

	free(*found);

	*found = to_promote;
}

bool set_contains(const set *s, double value)
{
	if (!s) {
		return false;
	}
	// Cast away const-ness; this function does not modify
	// s tree nor return any pointers to it
	struct node **found = tree_search((struct node **)&s->root, value, s->epsilon);

	if (*found) {
		return true;
	}

	return false;
}

bool set_is_empty(const set *s)
{
	return s && s->root == NULL;
}

// The function that was passed to set_iterate
// needs to be visible to both set_iterate and iter_wrapper.
static void (*iterate_function)(double);

// Wraps up the set_iterate function passed by user to match
// the signature for tree_inorder/tree_postorder functiens.
static void iter_wrapper(void *obj)
{
	if (!obj) {
		return;
	}
	struct node *node = obj;

	// This is already set by the user calling set_iterate
	iterate_function(node->data);
}

void set_iterate(set *s, void (*function)(double))
{
	if (!s) {
		return;
	}

	iterate_function = function;

	tree_inorder(s->root, iter_wrapper);
}

void set_destroy(set *s)
{
	if (!s) {
		return;
	}

	tree_postorder(s->root, free);

	free(s);
}
